package com.example.wrjts.demo16301093;

import android.app.Activity;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.VideoView;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.MediaController;
import android.widget.Toast;
import android.widget.VideoView;

public class VideoActivity extends AppCompatActivity {

//    private VideoView videoView1;
//    private String PATH_URL = "http://clips.vorwaerts-gmbh.de/big_buck_bunny.mp4";
    private VideoView videoview1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video);

        //本地的视频 需要在手机SD卡根目录添加一个Demo.mp4 视频
        // String videoUrl1 = Environment.getExternalStorageDirectory().getPath()+"/Demo.mp4" ;

        //网络视频

        videoview1 = (VideoView) this.findViewById(R.id.videoView1);

        //设置视频控制器
        videoview1.setMediaController(new MediaController(this));

        //播放完成回调
        videoview1.setOnCompletionListener(new MyPlayerOnCompletionListener());

        //设置视频路径
        //videoView.setVideoURI(uri);
        videoview1.setVideoPath("http://clips.vorwaerts-gmbh.de/big_buck_bunny.mp4");

        //开始播放视频
        videoview1.start();
    }

    class MyPlayerOnCompletionListener implements MediaPlayer.OnCompletionListener {

        @Override
        public void onCompletion(MediaPlayer mp) {
            Toast.makeText(VideoActivity.this, "播放完成了", Toast.LENGTH_SHORT).show();
        }
    }
}
